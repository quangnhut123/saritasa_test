<?php

return [
    'no_self_registration' => 'Self-registration is not enabled in this application. Please, go to user management to create new users'
];
